﻿
using DigitalCards.Services.Stickers.Models;
using DigitalCardsAppll.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DigitalCards.Services.Stickers
{
    public class StickerService : IStickerService
    {

        public readonly DigitalCardsDbContext data;

        public StickerService(DigitalCardsDbContext data)
        {
            this.data = data;
        }

        public IEnumerable<StickerAllServiceModel> All()
        {
            var stickers = this.data.Stickers
                .Select(c => new StickerAllServiceModel
                {
                    Id = c.Id,
                    Title = c.Title,
                    ImageUrl = c.ImageUrl,
                    SNumber = c.SNumber
                })
                .ToList();

            return stickers;
        }
        
        public int Add(string title, string imageurl, string topic, string artistname, string size, string snumber)
        {
            var sticker = new Sticker
            {
                Title = title,
                ImageUrl = imageurl,
                Topic = topic,
                ArtistName = artistname,
                Size = size,
                SNumber = snumber
            };

            this.data.Stickers.Add(sticker);
            this.data.SaveChanges();

            return sticker.Id;
        }

        public StickerDetailsServiceModel Details(int id)
        => this.data.Stickers.Where
                (c => c.Id == id)
                .Select(c => new StickerDetailsServiceModel
                {
                    Id = c.Id,
                    Title = c.Title,
                    ImageUrl = c.ImageUrl,
                    Topic = c.Topic,
                    ArtistName = c.ArtistName,
                    Size = c.Size,
                    SNumber = c.SNumber
                })
                .FirstOrDefault();

        public bool Delete(int id)
        {
            var sticker = this.data.Stickers.Find(id);

            this.data.Stickers.Remove(sticker);
            this.data.SaveChanges();

            return true;
        }


    }
}
