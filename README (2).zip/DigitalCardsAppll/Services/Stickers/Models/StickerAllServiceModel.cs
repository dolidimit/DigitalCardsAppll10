﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace DigitalCards.Services.Stickers.Models
{
    public class StickerAllServiceModel
    {
        public int Id { get; set; }

        public string Title { get; set; }

        [Url]
        public string ImageUrl { get; set; }

        public string SNumber { get; set; }

    }
}
