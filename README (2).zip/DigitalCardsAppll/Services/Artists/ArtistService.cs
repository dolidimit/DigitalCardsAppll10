﻿
using DigitalCardsAppll.Data;
using DigitalCardsAppll.Services.Artists.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DigitalCardsAppll.Services.Artists
{
    public class ArtistService : IArtistService
    {

        private readonly DigitalCardsDbContext data;

        public ArtistService(DigitalCardsDbContext data)
        {
            this.data = data;
        }

        public IEnumerable<ArtistAllServiceModel> All()
        {

            var artists = this.data.Artists
                .Select(c => new ArtistAllServiceModel
                {
                    Id = c.Id,
                    FullName = c.FullName,
                    ImageUrl = c.ImageUrl,
                    SImageUrl = c.SImageUrl
                })
                .ToList();

            return artists;
            
        }

        public bool Delete(int id)
        {
            var artist = this.data.Artists.Find(id);

            this.data.Artists.Remove(artist);
            this.data.SaveChanges();

            return true;
        }

    }
}
