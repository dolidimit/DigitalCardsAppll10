﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DigitalCardsAppll.Services.Artists.Models
{
    public class ArtistAllAdminServiceModel : ArtistServiceModel
    {
        public int Id { get; set; }

    }
}
