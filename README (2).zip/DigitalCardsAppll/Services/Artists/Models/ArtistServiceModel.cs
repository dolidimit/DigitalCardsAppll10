﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DigitalCardsAppll.Services.Artists.Models
{
    public class ArtistServiceModel
    {
        public string FullName { get; set; }

        public string ImageUrl { get; set; }

        public string SImageUrl { get; set; }

    }
}
