﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DigitalCardsAppll.Services.Artists.Models
{
    public class ArtistEditServiceModel : ArtistServiceModel
    {
        public int Id { get; set; }

    }
}
