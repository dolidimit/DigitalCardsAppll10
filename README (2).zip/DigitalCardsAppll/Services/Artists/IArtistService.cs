﻿
using DigitalCardsAppll.Services.Artists.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DigitalCardsAppll.Services.Artists
{
    public interface IArtistService
    {
        IEnumerable<ArtistAllServiceModel> All();

        bool Delete(int id);

    }
}
