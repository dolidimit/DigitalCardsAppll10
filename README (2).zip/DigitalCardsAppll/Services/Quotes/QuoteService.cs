﻿
using DigitalCardsAppll.Data;
using DigitalCardsAppll.Models.Quotes;
using DigitalCardsAppll.Services.Cards.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DigitalCardsAppll.Services.Quotes
{
    public class QuoteService : IQuoteService
    {

        private readonly DigitalCardsDbContext data;

        public QuoteService(DigitalCardsDbContext data)
        {
            this.data = data;
        }

        public IEnumerable<QuoteAllServiceModel> All()
        {
            var quotesl = this.data.Quotes.
                Select(q => new QuoteAllServiceModel
                {
                    Id = q.Id,
                    AuthorName = q.AuthorName,
                    Description = q.Description,
                    QNumber = q.QNumber
                })
                .ToList();

            return quotesl;

        }

        public QuoteDetailsServiceModel Details(int id)
         => this.data.Quotes.Where
                (c => c.Id == id)
                .Select(c => new QuoteDetailsServiceModel
                {
                    Id = c.Id,
                    AuthorName = c.AuthorName,
                    Year = c.Year,
                    Genre = c.Genre,
                    Description = c.Description,
                    QNumber = c.QNumber
                })
                .FirstOrDefault();

        public bool Delete(int id)
        {
            var quote = this.data.Quotes.Find(id);

            this.data.Quotes.Remove(quote);
            this.data.SaveChanges();

            return true;
        }

    }
}
