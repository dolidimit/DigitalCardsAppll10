﻿
using DigitalCardsAppll.Services.Cards.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DigitalCardsAppll.Services.Quotes
{
    public interface IQuoteService
    { 
        IEnumerable<QuoteAllServiceModel> All();

        QuoteDetailsServiceModel Details(int id);

        bool Delete(int id);

    }
}
