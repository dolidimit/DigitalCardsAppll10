﻿using DigitalCardsAppll.Services.Quotes.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace DigitalCardsAppll.Services.Cards.Models
{
    public class QuoteServiceModel : IQuoteModel
    {
        public int Id { get; set; }

        [Required]
        [MaxLength(30)]
        [Display(Name = "Author")]
        public string AuthorName { get; set; }

        [Required]
        [MaxLength(4)]
        public string Year { get; set; }

        [Required]
        [MaxLength(20)]
        public string Genre { get; set; }

        [Required]
        [MaxLength(50)]
        public string Description { get; set; }

        [Required]
        [Display(Name = "Number")]
        public string QNumber { get; set; }
    }
}
