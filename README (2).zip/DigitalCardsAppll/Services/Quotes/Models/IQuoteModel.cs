﻿namespace DigitalCardsAppll.Services.Quotes.Models
{
    public interface IQuoteModel
    {
        string AuthorName { get; }

        string Description { get; }

        string Year { get; }
    }
}
