﻿
using DigitalCardsAppll.Data;
using DigitalCardsAppll.Services.Authors.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DigitalCardsAppll.Services.Authors
{
    public class AuthorService : IAuthorService
    {

        private readonly DigitalCardsDbContext data;

        public AuthorService(DigitalCardsDbContext data)
        {
            this.data = data;
        }
        public IEnumerable<AuthorAllServiceModel> All()
        {
            var authors = this.data.Authors
                .Select(c => new AuthorAllServiceModel
                {
                    Id = c.Id,
                    FullName = c.FullName,
                    ImageUrl = c.ImageUrl,
                    PQuote = c.PQuote
                })
                .ToList();

            return authors;
        }

        public bool Delete(int id)
        {
            var author = this.data.Authors.Find(id);

            this.data.Authors.Remove(author);
            this.data.SaveChanges();

            return true;
        }

    }
}
