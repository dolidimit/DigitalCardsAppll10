﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DigitalCardsAppll.Services.Authors.Models
{
    public class AuthorAllServiceModel : AuthorServiceModel
    {
        public int Id { get; set; }

    }
}
