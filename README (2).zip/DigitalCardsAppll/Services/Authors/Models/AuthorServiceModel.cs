﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DigitalCardsAppll.Services.Authors.Models
{
    public class AuthorServiceModel
    {
        public string FullName { get; set; }

        public string ImageUrl { get; set; }

        public string PQuote { get; set; }

    }
}
