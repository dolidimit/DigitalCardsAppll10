﻿
using DigitalCardsAppll.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using DigitalCardsAppll.Services.Cards.Models;

namespace DigitalCardsAppll.Services.Cards
{
    public abstract class CardService : ICardService
    {

        private readonly DigitalCardsDbContext data;

        public CardService(DigitalCardsDbContext data)
        {
            this.data = data;
        }

        public IEnumerable<CardAllServiceModel> All()
        {
            var cards = this.data.Cards
                .Select(c => new CardAllServiceModel
                {
                    Id = c.Id,
                    Title = c.Title,
                    ImageUrl = c.ImageUrl,
                    Destination = c.Destination
                })
                .ToList();

            return cards;
        }

        public IEnumerable<CardPersonalServiceModel> AllPrivate()
        {
           var cardsp =  this.data.Cards
                 .Select(c => new CardPersonalServiceModel
                 {
                     Id = c.Id,
                     Title = c.Title,
                     ImageUrl = c.ImageUrl,
                     Destination = c.Destination,
                     SNumber = c.SNumber,
                     QNumber = c.QNumber
                 })
                 .ToList();

            return cardsp;
        }

        public CardDetailsServiceModel Details(int cardid)
        => this.data.Cards.Where(c => c.Id == cardid)
                .Select(c => new CardDetailsServiceModel
                {
                    Id = c.Id,
                    Title = c.Title,
                    ImageUrl = c.ImageUrl,
                    Destination = c.Destination,
                    SNumber = c.SNumber,
                    QNumber = c.QNumber
                })
                .FirstOrDefault();


        public bool Delete(int id)
        {
            var card = this.data.Cards.Find(id);

            this.data.Cards.Remove(card);
            this.data.SaveChanges();

            return true;
        }


    }
}
