﻿
using DigitalCardsAppll.Services.Cards.Models;
using System.Collections.Generic;

namespace DigitalCardsAppll.Services.Cards
{
    public interface ICardService
    {
        IEnumerable<CardAllServiceModel> All();

        CardDetailsServiceModel Details(int cardid);

        IEnumerable<CardPersonalServiceModel> AllPrivate();

        bool Delete(int id);

    }
}
