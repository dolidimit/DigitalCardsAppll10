﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DigitalCardsAppll.Services.Cards.Models
{
    public class CardPersonalServiceModel
    {
        public int Id { get; set; }

        public string Title { get; set; }

        public string ImageUrl { get; set; }

        public string Destination { get; set; }

        public string SNumber { get; set; }

        public string QNumber { get; set; }
    }
}
