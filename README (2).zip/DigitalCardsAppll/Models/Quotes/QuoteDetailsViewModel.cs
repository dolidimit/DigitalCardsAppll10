﻿namespace DigitalCardsAppll.Models.Quotes
{
    public class QuoteDetailsViewModel : QuoteAddViewModel
    {
        public int Id { get; set; }

    }
}
