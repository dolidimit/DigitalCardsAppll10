﻿namespace DigitalCardsAppll.Models.Quotes
{
    public class QuoteAllAdminViewModel : QuoteAddViewModel
    {
        public int Id { get; set; }

    }
}
