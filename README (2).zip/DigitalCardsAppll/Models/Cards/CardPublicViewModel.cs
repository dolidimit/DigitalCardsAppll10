﻿namespace DigitalCardsAppll.Models.Cards
{
    public class CardPublicViewModel : CardAllViewModel
    {
    }
}
