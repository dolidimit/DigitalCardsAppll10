﻿namespace DigitalCardsAppll.Models.Cards
{
    public class CardAllAdminViewModel : CardAddAdminViewModel
    {
        public int Id { get; set; }

    }
}
