﻿namespace DigitalCardsAppll.Models.Cards
{
    public class CardDetailsViewModel : CardAddViewModel
    {
        public int Id { get; set; }

    }
}
