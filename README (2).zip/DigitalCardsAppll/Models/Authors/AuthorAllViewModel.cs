﻿using DigitalCardsAppll.Models.Authors;

namespace DigitalCardsAppll.Models.Author
{
    public class AuthorAllViewModel : AuthorAddViewModel
    {
        public int Id { get; set; }

    }
}
