﻿using DigitalCardsAppll.Models.Authors;

namespace DigitalCardsAppll.Models.Author
{
    public class AuthorAllAdminViewModel : AuthorAddViewModel
    {
        public int Id { get; set; }

    }
}
