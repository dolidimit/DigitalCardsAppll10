﻿namespace DigitalCardsAppll.Models.Artists
{
    public class ArtistAllAdminViewModel : ArtistAddViewModel
    {
        public int Id { get; set; }

    }
}
