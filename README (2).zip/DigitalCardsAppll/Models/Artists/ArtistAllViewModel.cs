﻿namespace DigitalCardsAppll.Models.Artists
{
    public class ArtistAllViewModel
    {
        public int Id { get; set; }

        public string FullName { get; set; }

        public string ImageUrl { get; set; }

        public string SImageUrl { get; set; }

    }
}
