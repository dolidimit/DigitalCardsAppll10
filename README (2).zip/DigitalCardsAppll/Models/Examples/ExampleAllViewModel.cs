﻿using DigitalCardsAppll.Models.Examples;

namespace DigitalCardsAppll.Models.Examples
{
    public class ExampleAllViewModel : ExampleAddViewModel
    {
        public int Id { get; set; }

    }
}
