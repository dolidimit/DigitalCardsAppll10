﻿namespace DigitalCardsAppll.Models.Stickers
{
    public class StickerAllViewModel
    {
        public int Id { get; set; }

        public string Title { get; set; }

        public string ImageUrl { get; set; }

        public string SNumber { get; set; }

    }
}
