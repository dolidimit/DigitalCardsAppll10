﻿namespace DigitalCardsAppll.Models.Stickers
{
    public class StickerDetailsViewModel : StickerAddViewModel
    {
        public int Id { get; set; }

    }
}
