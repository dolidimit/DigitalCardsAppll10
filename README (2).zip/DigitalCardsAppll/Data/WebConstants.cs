﻿namespace DigitalCardsAppll.Data
{
    public class WebConstants
    {
        public const string AreaName = "Admin";
        public const string AdministratorRoleName = "Administrator";
    }
}
