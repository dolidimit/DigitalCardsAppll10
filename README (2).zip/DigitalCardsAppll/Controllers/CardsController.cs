﻿using DigitalCardsAppll.Data;
using DigitalCardsAppll.Models.Cards;
using DigitalCardsAppll.Services.Cards;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Linq;

namespace DigitalCardsAppll.Controllers
{
    public class CardsController : Controller
    {

        private readonly ICardService service;

        public CardsController(ICardService service)
        {
            this.service = service;
        }

        public IActionResult All()
        {
            var cards = this.service.All();

            return View(cards);
        }

        public IActionResult AllPrivate()
        {
            var cards = this.service.AllPrivate();

            return View(cards);
        }

        public IActionResult Details(int id)
        {
            if (id == 0)
            {
                return BadRequest();
            }

            var card = this.service.Details(id);

            return View(card);

        }

        public IActionResult Delete(int id)
        {
            var card = this.service.Delete(id);

            return RedirectToAction("AllAdminCards", "Collections");

        }


    }
}
