﻿using DigitalCardsAppll.Data;
using DigitalCardsAppll.Models.Examples;
using Microsoft.AspNetCore.Mvc;
using System.Linq;

namespace DigitalCardsAppll.Controllers
{
    public class ExamplesController : Controller
    {
        private readonly DigitalCardsDbContext data;

        public ExamplesController(DigitalCardsDbContext data)
        {
            this.data = data;
        }
        public IActionResult All()
        {

            var examples = this.data.Examples
                .Select(c => new ExampleAllViewModel
                {
                    Id = c.Id,
                    Description = c.Description,
                    ImageUrl = c.ImageUrl
                })
                .ToList();

            return View(examples);

        }

    }
}
