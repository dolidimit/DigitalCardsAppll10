﻿using DigitalCards.Services.Stickers;
using DigitalCardsAppll.Data;
using DigitalCardsAppll.Models.Stickers;
using Microsoft.AspNetCore.Mvc;
using System.Linq;

namespace DigitalCardsAppll.Controllers
{
    public class StickersController : Controller
    {

        private readonly IStickerService service;

        public StickersController(IStickerService service)
        {
            this.service = service;
        }

        public IActionResult All()
        {
            var stickers  = this.service.All();

            return View(stickers);
        }

        public IActionResult Details(int stickerid)
        {
            if (stickerid == 0)
            {
                return BadRequest();
            }

            var sticker = this.service.Details(stickerid);

            return View(sticker);

        }

        public IActionResult Delete(int stickerid)
        {
            var sticker = this.service.Delete(stickerid);

            return RedirectToAction("AllAdminQuotes", "Collections");

        }

    }
}
