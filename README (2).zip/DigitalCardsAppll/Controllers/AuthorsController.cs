﻿using DigitalCardsAppll.Data;
using DigitalCardsAppll.Models.Author;
using DigitalCardsAppll.Models.Authors;
using DigitalCardsAppll.Services.Authors;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Linq;

namespace DigitalCardsAppll.Controllers
{
    public class AuthorsController : Controller
    {

        private readonly IAuthorService service;

        public AuthorsController(IAuthorService service)
        {
            this.service = service;
        }

        public IActionResult All()
        {
            var authors = this.service.All();

            return View(authors);
        }

        public IActionResult Delete(int id)
        {
            var author = this.service.Delete(id);

            return RedirectToAction("AllAdminAuthors", "Collections");

        }

    }
}
