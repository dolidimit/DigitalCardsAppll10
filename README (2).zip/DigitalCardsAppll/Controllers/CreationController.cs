﻿using DigitalCardsAppll.Data;
using DigitalCardsAppll.Models.Artists;
using DigitalCardsAppll.Models.Authors;
using DigitalCardsAppll.Models.Cards;
using DigitalCardsAppll.Models.Examples;
using DigitalCardsAppll.Models.Stickers;
using DigitalCardsAppll.Models.Quotes;
using Microsoft.AspNetCore.Mvc;

namespace DigitalCardsAppll.Controllers
{
    public class CreationController : Controller
    {

        private readonly DigitalCardsDbContext data;

        public CreationController(DigitalCardsDbContext data)
        {
            this.data = data;
        }

        public IActionResult AddCard() => View();

        [HttpPost]
        public IActionResult AddCard(CardAddViewModel card)
        {
            if (!ModelState.IsValid)
            {
                return View(card);
            }


            var cardd = new Card
            {
                Title = card.Title,
                Destination = card.Destination,
                ImageUrl = card.ImageUrl,
                Receiver = card.Receiver,
                Model = card.Model,
                SNumber = card.SNumber,
                QNumber = card.QNumber,
                PublicView = card.PublicView
            };

            this.data.Cards.Add(cardd);
            this.data.SaveChanges();

            return RedirectToAction("All", "Cards");
        }

        public IActionResult AddSticker() => View();

        [HttpPost]
        public IActionResult AddSticker(StickerAddViewModel sticker)
        {
            if (!ModelState.IsValid)
            {
                return View(sticker);
            }

            var stickerr = new Sticker
            {
                Title = sticker.Title,
                ImageUrl = sticker.ImageUrl,
                Topic = sticker.Topic,
                ArtistName = sticker.ArtistName,
                Size = sticker.Size,
                SNumber = sticker.SNumber
            };

            this.data.Stickers.Add(stickerr);
            this.data.SaveChanges();

            return RedirectToAction("All", "Stickers");
        }

        public IActionResult AddQuote() => View();

        [HttpPost]
        public IActionResult AddQuote(QuoteAddViewModel quote)
        {
            if (!ModelState.IsValid)
            {
                return View(quote);
            }

            var quote2 = new Quote
            {
                AuthorName = quote.AuthorName,
                Description = quote.Description,
                Genre = quote.Genre,
                Year = quote.Year,
                QNumber = quote.QNumber
            };

            this.data.Quotes.Add(quote2);
            this.data.SaveChanges();

            return RedirectToAction("All", "Quotes");
        }

        public IActionResult AddArtist() => View();

        [HttpPost]
        public IActionResult AddArtist(ArtistAddViewModel artist)
        {
            if (!ModelState.IsValid)
            {
                return View(artist);
            }

            var artist2 = new Artist
            {
                FullName = artist.FullName,
                ImageUrl = artist.ImageUrl,
                SImageUrl = artist.SImageUrl
            };

            this.data.Artists.Add(artist2);
            this.data.SaveChanges();

            return RedirectToAction("All", "Artists");
        }

        public IActionResult AddAuthor() => View();

        [HttpPost]
        public IActionResult AddAuthor(AuthorAddViewModel author)
        {
            if (!ModelState.IsValid)
            {
                return View(author);
            }

            var authorr = new Author
            {
                FullName = author.FullName,
                ImageUrl = author.ImageUrl,
                PQuote = author.PQuote
            };

            this.data.Authors.Add(authorr);
            this.data.SaveChanges();

            return RedirectToAction("All", "Authors");
        }

        public IActionResult AddExample() => View();

        [HttpPost]
        public IActionResult AddExample(ExampleAddViewModel example)
        {
            if (!ModelState.IsValid)
            {
                return View(example);
            }

            var example1 = new Example
            {
                Description = example.Description,
                ImageUrl = example.ImageUrl
            };

            this.data.Examples.Add(example1);
            this.data.SaveChanges();

            return RedirectToAction("All", "Examples");
        }


    }
}
