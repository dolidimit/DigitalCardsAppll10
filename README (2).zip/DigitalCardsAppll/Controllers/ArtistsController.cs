﻿using DigitalCardsAppll.Data;
using DigitalCardsAppll.Models.Artists;
using DigitalCardsAppll.Services.Artists;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Linq;

namespace DigitalCardsAppll.Controllers
{
    public class ArtistsController : Controller
    {

        private readonly IArtistService service;

        public ArtistsController(IArtistService service)
        {
            this.service = service;
        }

        public IActionResult All()
        {
            var artists = this.service.All();

            return View(artists);
        }

        public IActionResult Delete(int id)
        {
            var artist = this.service.Delete(id);

            return RedirectToAction("AllAdminArtists", "Collections");

        }


    }
}
