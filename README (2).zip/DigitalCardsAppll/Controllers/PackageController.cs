﻿using DigitalCardsAppll.Data;
using DigitalCardsAppll.Models.Cards;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;

namespace DigitalCardsAppll.Controllers
{
    public class PackageController : Controller
    {

        private readonly DigitalCardsDbContext data;

        public PackageController(DigitalCardsDbContext data)
        {
            this.data = data;
        }

        public IActionResult YourCards()
        {
            var cards = this.data.Cards
                .ToList();

            var cardsl = cards
                .Select(c => new CardPrivateViewModel
                {
                    Id = c.Id,
                    Title = c.Title,
                    ImageUrl = c.ImageUrl,
                    Destination = c.Destination,
                    Receiver = c.Receiver,
                    Model = c.Model,
                    SNumber = c.SNumber,
                    QNumber = c.QNumber,
                    PublicView = c.PublicView
                })
                .ToList();

            return View(cardsl);

        }

        public IActionResult Delete(int cardId)
        {
            var card = this.data.Cards.Find(cardId);

            if (card == null)
            {
                return BadRequest();
            }

            this.data.Cards.Remove(card);
            this.data.SaveChanges();

            return RedirectToAction("YourCards", "Package");
        }


    }
}
