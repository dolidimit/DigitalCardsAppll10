﻿using DigitalCardsAppll.Data;
using DigitalCardsAppll.Models.Quotes;
using DigitalCardsAppll.Services.Cards.Models;
using DigitalCardsAppll.Services.Quotes;
using Microsoft.AspNetCore.Mvc;
using System.Linq;

namespace DigitalCardsAppll.Controllers
{
    public class QuotesController : Controller
    {

        private readonly IQuoteService service;

        public QuotesController(IQuoteService service)
        {
            this.service = service;
        }

        public IActionResult All()
        {
            var quotes = this.service.All();

            return View(quotes);
        }

        public IActionResult Details(int quoteid)
        {
            if(quoteid == 0)
            {
                return BadRequest();
            }

            var quote = this.service.Details(quoteid);
           
            return View(quote);

        }

        public IActionResult Delete(int quoteid)
        {
            var quote = this.service.Delete(quoteid);

            return RedirectToAction("AllAdminQuotes", "Collections");

        }
     

    }
}
